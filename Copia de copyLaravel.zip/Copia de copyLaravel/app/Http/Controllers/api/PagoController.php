<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Pago;
use Illuminate\Http\Request;

class PagoController extends Controller
{
    public function index(Request $request)
    {
        // Mostrar pagos
    }

    public function create(Request $request)
    {
        // Crear pago
    }

    public function show($id)
    {
        // Mostrar un pago
    }

    public function destroy($id)
    {
        // Eliminar pago
    }
}
