<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Rol;
use Illuminate\Http\Request;

class RolController extends Controller
{
    public function index(Request $request)
    {
        // Listar roles
    }

    public function create(Request $request)
    {
        // Crear rol
    }

    public function show($id)
    {
        // Mostrar rol
    }

    public function update(Request $request, $id)
    {
        // Actualizar rol
    }

    public function destroy($id)
    {
        // Eliminar rol
    }
}
